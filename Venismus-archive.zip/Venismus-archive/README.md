# Venismus Archive

Tento archiv slouží k uložení všeho, co jsme vytvořili a co má potenciál k využití nebo prodeji.  
Je rozdělen na **technická aktiva** (GitHub) a **kreativní/strategická aktiva** (Google Drive).

---

## 🔹 Struktura GitHub (technická část)
```
venismus/
 ├── web/             # Web venismus.com (frontend, backend, api)
 ├── ai-models/       # AI skripty, nastavení, token systém
 ├── utils/           # Pomocné skripty (deploy, integrace)
 └── docs/            # Dokumentace, návody k nasazení
```

---

## 🔹 Struktura Google Drive (kreativa & obchod)
```
Venismus Archive/
 ├── Branding/        # Loga, barvy, UI, design
 ├── Images/          # Generované obrázky, vizuály, fotobanky
 ├── Texts/           # Příběhy, popisy, scénáře, marketingové texty
 ├── Strategy/        # Obchodní modely, token systém, nápady na monetizaci
 └── Releases/        # Hotové balíčky na prodej nebo veřejné spuštění
```

---

## 🔹 Účel
- Uchovat vše, co má hodnotu (prodejní, kreativní, technickou).  
- Mít jasný přehled o stavu projektu.  
- Rychle najít aktiva připravená k použití nebo monetizaci.  

---

## 🔹 Další kroky
- [ ] Nahodit základní složky na GitHub.  
- [ ] Vytvořit paralelní složky na Google Drive.  
- [ ] Přidat první soubory (loga, obrázky, kód, texty).  
- [ ] Pravidelně doplňovat přehled změn.  

---

✍️ Archiv je živý dokument – cokoliv vytvoříme, sem patří.
